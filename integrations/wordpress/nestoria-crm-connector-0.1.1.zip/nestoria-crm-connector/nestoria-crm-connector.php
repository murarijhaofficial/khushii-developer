<?php
/**
 * Plugin Name: Khushii CRM Connector for Nestoria
 * Description: Queues Nestoria Property Projects enquiries for signed delivery to Khushii CRM.
 * Version: 0.1.1
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/khushii-crm-client.php';

const KHUSHII_NPP_CRON = 'khushii_npp_deliver_enquiry';

function khushii_npp_configured() {
    $url = defined( 'KHUSHII_CRM_API_URL' ) ? KHUSHII_CRM_API_URL : getenv( 'KHUSHII_CRM_API_URL' );
    $secret = defined( 'KHUSHII_CRM_WEBHOOK_SECRET' ) ? KHUSHII_CRM_WEBHOOK_SECRET : getenv( 'KHUSHII_CRM_WEBHOOK_SECRET' );
    return is_string( $url ) && wp_http_validate_url( $url ) && 'https' === wp_parse_url( $url, PHP_URL_SCHEME ) && is_string( $secret ) && strlen( $secret ) >= 24;
}

/** Convert explicit international numbers, or Indian 10-digit mobiles, to E.164. */
function khushii_npp_phone( $raw ) {
    $raw = trim( (string) $raw );
    if ( ! preg_match( '/^[0-9+\s().-]{7,20}$/', $raw ) || substr_count( $raw, '+' ) > 1 || ( strpos( $raw, '+' ) !== false && strpos( $raw, '+' ) !== 0 ) ) { return ''; }
    $digits = preg_replace( '/\D/', '', $raw );
    if ( isset( $raw[0] ) && '+' === $raw[0] ) { $phone = '+' . $digits; }
    elseif ( preg_match( '/^0[6-9][0-9]{9}$/', $digits ) ) { $phone = '+91' . substr( $digits, 1 ); }
    elseif ( preg_match( '/^[6-9][0-9]{9}$/', $digits ) ) { $phone = '+91' . $digits; }
    elseif ( preg_match( '/^91[6-9][0-9]{9}$/', $digits ) ) { $phone = '+' . $digits; }
    else { return ''; }
    return preg_match( '/^\+[1-9][0-9]{7,14}$/', $phone ) ? $phone : '';
}

function khushii_npp_queue( $lead_id ) {
    $lead_id = absint( $lead_id );
    if ( 'npp_lead' !== get_post_type( $lead_id ) || 'private' !== get_post_status( $lead_id ) || 'sent' === get_post_meta( $lead_id, '_khushii_crm_status', true ) ) { return false; }
    if ( ! khushii_npp_configured() ) { update_post_meta( $lead_id, '_khushii_crm_status', 'waiting' ); return false; }
    $args = array( $lead_id );
    if ( ! wp_next_scheduled( KHUSHII_NPP_CRON, $args ) ) {
        $scheduled = wp_schedule_single_event( time() + 10, KHUSHII_NPP_CRON, $args, true );
        if ( is_wp_error( $scheduled ) || ! $scheduled ) { update_post_meta( $lead_id, '_khushii_crm_status', 'failed' ); return false; }
    }
    update_post_meta( $lead_id, '_khushii_crm_status', 'queued' );
    return true;
}

/** Nestoria writes this key after all other enquiry metadata. */
function khushii_npp_meta_saved( $meta_id, $post_id, $meta_key, $meta_value ) {
    if ( '_npp_lead_source_url' === $meta_key && 'npp_lead' === get_post_type( $post_id ) ) { khushii_npp_queue( $post_id ); }
}
add_action( 'added_post_meta', 'khushii_npp_meta_saved', 10, 4 );

function khushii_npp_deliver( $lead_id ) {
    $lead_id = absint( $lead_id );
    if ( 'npp_lead' !== get_post_type( $lead_id ) || 'private' !== get_post_status( $lead_id ) || 'sent' === get_post_meta( $lead_id, '_khushii_crm_status', true ) ) { return; }
    $lock = (int) get_post_meta( $lead_id, '_khushii_crm_lock', true );
    if ( $lock && $lock < time() - 900 ) { delete_post_meta( $lead_id, '_khushii_crm_lock', (string) $lock ); }
    if ( ! add_post_meta( $lead_id, '_khushii_crm_lock', (string) time(), true ) ) { return; }
    try {
        $name = (string) get_post_meta( $lead_id, '_npp_lead_name', true );
        $phone = khushii_npp_phone( get_post_meta( $lead_id, '_npp_lead_phone', true ) );
        $email = (string) get_post_meta( $lead_id, '_npp_lead_email', true );
        if ( 'Not provided' === $email ) { $email = ''; }
        if ( strlen( $name ) < 2 || ! $phone || ( $email && ! is_email( $email ) ) ) {
            update_post_meta( $lead_id, '_khushii_crm_status', 'needs_review' );
            return;
        }
        $fields = array( 'Project' => 'project', 'Plot size' => 'plotsize', 'Budget' => 'budget', 'Preferred visit' => 'preferredsitevisit', 'Message' => 'message' );
        $parts = array();
        foreach ( $fields as $label => $key ) {
            $value = trim( (string) get_post_meta( $lead_id, '_npp_lead_' . $key, true ) );
            if ( '' !== $value ) { $parts[] = $label . ': ' . $value; }
        }
        $source_url = (string) get_post_meta( $lead_id, '_npp_lead_source_url', true );
        if ( $source_url ) { $parts[] = 'Source page: ' . esc_url_raw( $source_url ); }
        $message = wp_html_excerpt( implode( "\n", $parts ), 3000, '' );
        $project_id = absint( get_post_meta( $lead_id, '_npp_lead_project_id', true ) );
        $slug = $project_id && 'npp_project' === get_post_type( $project_id ) ? (string) get_post_field( 'post_name', $project_id ) : '';
        $submission_id = 'nestoria:' . substr( hash( 'sha256', home_url( '/' ) ), 0, 24 ) . ':' . $lead_id;
        $result = khushii_crm_send_website_lead( $submission_id, $name, $phone, $email, $message, $slug );
        if ( ! is_wp_error( $result ) ) {
            update_post_meta( $lead_id, '_khushii_crm_status', 'sent' );
            update_post_meta( $lead_id, '_khushii_crm_lead_id', sanitize_text_field( $result['id'] ) );
            delete_post_meta( $lead_id, '_khushii_crm_attempts' );
            return;
        }
        $attempt = (int) get_post_meta( $lead_id, '_khushii_crm_attempts', true ) + 1;
        update_post_meta( $lead_id, '_khushii_crm_attempts', $attempt );
        update_post_meta( $lead_id, '_khushii_crm_status', 'failed' );
        $delays = array( 60, 300, 900, 3600, 21600 );
        if ( $attempt <= count( $delays ) && khushii_npp_configured() ) {
            $scheduled = wp_schedule_single_event( time() + $delays[ $attempt - 1 ], KHUSHII_NPP_CRON, array( $lead_id ), true );
            if ( ! is_wp_error( $scheduled ) && $scheduled ) { update_post_meta( $lead_id, '_khushii_crm_status', 'queued' ); }
        }
    } finally {
        delete_post_meta( $lead_id, '_khushii_crm_lock' );
    }
}
add_action( KHUSHII_NPP_CRON, 'khushii_npp_deliver' );

function khushii_npp_menu() { add_submenu_page( 'edit.php?post_type=npp_project', 'CRM Connector', 'CRM Connector', 'manage_options', 'khushii-npp-connector', 'khushii_npp_admin_page' ); }
add_action( 'admin_menu', 'khushii_npp_menu' );
function khushii_npp_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    echo '<div class="wrap"><h1>Khushii CRM Connector</h1><p>Connection configuration: <strong>' . ( khushii_npp_configured() ? 'Configured (delivery not verified)' : 'Not configured' ) . '</strong></p>';
    echo '<p>Set KHUSHII_CRM_API_URL and KHUSHII_CRM_WEBHOOK_SECRET in wp-config.php or the server environment. The API URL must use HTTPS and end in /api/v1. The secret must match the CRM API server. See the connector README.</p>';
    echo '<p>New Nestoria enquiries are queued automatically. Existing and failed enquiries can be queued in batches of up to 100. Repeat until none are queued. Invalid names, phone numbers or emails are marked for review in Property Enquiries and are excluded from bulk retry. Local 10-digit Indian mobile numbers are normalized to +91.</p>';
    echo '<p>WordPress Cron requires site traffic or a real server cron job. Successful configuration alone does not confirm delivery.</p>';
    echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
    wp_nonce_field( 'khushii_npp_queue_existing' );
    echo '<input type="hidden" name="action" value="khushii_npp_queue_existing">';
    submit_button( 'Queue up to 100 unsent enquiries' );
    echo '</form>';
    if ( isset( $_GET['queued'] ) ) { echo '<p>Queued: ' . esc_html( (string) absint( $_GET['queued'] ) ) . '</p>'; }
    echo '</div>';
}
function khushii_npp_queue_existing() {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden', '', array( 'response' => 403 ) ); }
    check_admin_referer( 'khushii_npp_queue_existing' );
    if ( ! khushii_npp_configured() ) { wp_die( 'Configure the CRM connection before queueing enquiries.' ); }
    $ids = get_posts( array( 'post_type' => 'npp_lead', 'post_status' => 'private', 'posts_per_page' => 100, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'meta_query' => array( 'relation' => 'OR', array( 'key' => '_khushii_crm_status', 'compare' => 'NOT EXISTS' ), array( 'key' => '_khushii_crm_status', 'value' => array( 'waiting', 'failed' ), 'compare' => 'IN' ) ) ) );
    $queued = 0;
    foreach ( $ids as $id ) { delete_post_meta( $id, '_khushii_crm_attempts' ); if ( khushii_npp_queue( $id ) ) { $queued++; } }
    wp_safe_redirect( add_query_arg( array( 'post_type' => 'npp_project', 'page' => 'khushii-npp-connector', 'queued' => $queued ), admin_url( 'edit.php' ) ) );
    exit;
}
add_action( 'admin_post_khushii_npp_queue_existing', 'khushii_npp_queue_existing' );

function khushii_npp_lead_columns( $columns ) { $columns['khushii_crm'] = 'CRM sync'; return $columns; }
add_filter( 'manage_npp_lead_posts_columns', 'khushii_npp_lead_columns', 20 );
function khushii_npp_lead_column( $column, $post_id ) {
    if ( 'khushii_crm' !== $column ) { return; }
    $labels = array( 'sent' => 'Sent', 'queued' => 'Queued', 'waiting' => 'Needs configuration', 'failed' => 'Delivery failed', 'needs_review' => 'Check name, phone or email' );
    $status = (string) get_post_meta( $post_id, '_khushii_crm_status', true );
    echo esc_html( isset( $labels[ $status ] ) ? $labels[ $status ] : 'Not queued' );
}
add_action( 'manage_npp_lead_posts_custom_column', 'khushii_npp_lead_column', 20, 2 );
