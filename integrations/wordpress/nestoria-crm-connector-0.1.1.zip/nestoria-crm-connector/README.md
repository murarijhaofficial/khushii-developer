# Khushii CRM Connector for Nestoria

This add-on is designed for Nestoria Property Projects 2.2.0 as supplied. It keeps the existing plugin intact. It watches the final saved enquiry metadata and schedules signed, server-to-server delivery to the CRM. Install this folder as a separate WordPress plugin while Nestoria remains active.

## Setup

1. Deploy the CRM API to a publicly reachable HTTPS address and apply its database migrations. The local `localhost:4000` API is not reachable by a remote WordPress site.
2. On the WordPress server, set these constants in `wp-config.php` before the line saying to stop editing (or set the same names as server environment variables):

   ```php
   define('KHUSHII_CRM_API_URL', 'https://YOUR-CRM-API.example/api/v1');
   define('KHUSHII_CRM_WEBHOOK_SECRET', 'YOUR-SERVER-SIDE-INTEGRATION-SECRET');
   ```

   The secret must equal the CRM API's `WEBHOOK_SHARED_SECRET` (at least 24 characters). Use the same exact secret; do not put it in web pages, JavaScript, the repository, or a support message.
3. Upload and activate `nestoria-crm-connector-0.1.1.zip` under Plugins > Add New. Do not replace or deactivate Nestoria Property Projects.
4. Under Property Projects > CRM Connector, check configuration and queue existing unsent enquiries in batches of 100. Repeat for additional batches. The Property Enquiries list shows a CRM sync column.
5. Make one real test submission on your website, allow WP-Cron to run, and verify it is marked Sent in WordPress and appears in CRM Leads. Configuration status by itself does not verify a connection.

WordPress Cron is traffic-driven. For dependable delivery configure a real server cron to invoke WordPress Cron according to your hosting setup. Delivery failures retry up to five times, then remain marked Delivery failed and can be queued again. Review invalid name, phone, or email records before requeueing; review statuses are excluded from bulk retry, so after a developer corrects the underlying WordPress metadata, clear `_khushii_crm_status` for that enquiry and queue it again. Do not treat Sent as a guarantee of downstream employee follow-up.

The connector maps name, phone, optional email, project slug, project name, plot size, budget, preferred visit date, message and source page. Non-`+` Indian mobile numbers with 10 digits (optionally prefixed by `0` or `91`) are normalized to +91; other local numbers are marked for review. A WordPress project slug associates with a CRM project only if their slugs match; the project name is also retained in enquiry details. An enquiry's stable delivery ID is derived from the WordPress site URL and lead post ID; retries on the same site are idempotent. Changing the site URL or cloning its database to another URL changes that ID and may produce duplicates if previously sent records are reimported.

The original Nestoria plugin stores a contact enquiry; it does not persist proof of WhatsApp marketing consent. This connector does not infer or create marketing consent. Automatic WhatsApp marketing is not enabled.

Compatibility was checked against the supplied plugin source, and the connector has PHP syntax and stubbed behavior tests. Test on a staging copy of the actual site before production. This add-on does not modify the supplied Nestoria plugin or connect it automatically.
